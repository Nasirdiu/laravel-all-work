<?php $__env->startSection('content'); ?>
    <div style="text-align: center; margin-left: 350px">
        <div class="d-grid mx-auto" style="margin-bottom: 50px" >
            <a href="<?php echo e(url('addIncome')); ?>" class="btn btn-primary btn-block w-50">Add Income</a>
        </div>

        <div class="d-grid mx-auto" style="margin-bottom: 50px" >
            <a href="<?php echo e(url('incomeView')); ?>" class="btn btn-danger btn-block w-50">View Income</a>
        </div>

        <div class="d-grid mx-auto" >
            <a href="<?php echo e(url('filterIncome')); ?>" class="btn btn-dark btn-block w-50">Filter Income</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nasir Vai Assignment\Assignment\resources\views/income/income.blade.php ENDPATH**/ ?>