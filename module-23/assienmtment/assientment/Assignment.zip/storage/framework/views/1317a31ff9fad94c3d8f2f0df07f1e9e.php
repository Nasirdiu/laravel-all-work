<?php $__env->startSection('content'); ?>
    <div style="text-align: center; margin-left: 350px">
        <div class="d-grid mx-auto" style="margin-bottom: 50px" >
            <a href="<?php echo e(url('dateIncome')); ?>" class="btn btn-primary btn-block w-50">Income Filter By Date</a>
        </div>

        <div class="d-grid mx-auto" style="margin-bottom: 50px" >
            <a href="<?php echo e(url('amountIncomeAsc')); ?>" style="margin-bottom: 20px" class="btn btn-dark btn-danger w-50">Income Filter By Asc Amount</a>
            <a href="<?php echo e(url('amountIncomeDsc')); ?>" class="btn btn-dark btn-dark w-50">Income Filter By Dsc Amount</a>
        </div>

        <div class="d-grid mx-auto" style="margin-bottom: 60px" >
            <a href="<?php echo e(url('filterIncomeCat')); ?>" class="btn btn-warning btn-block w-50">Income Filter By Category</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nasir Vai Assignment\Assignment\resources\views/income/filterIncome.blade.php ENDPATH**/ ?>