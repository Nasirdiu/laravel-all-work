<?php $__env->startSection('content'); ?>
    <main class="login-form">
        <div class="cotainer">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="card">
                        <h3 class="card-header text-center">Filter By Date</h3>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(url('filterByDateIncome')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <input type="date"  class="form-control" name="start_date" required>
                                </div>
                                <div class="form-group mb-3">
                                    <input type="date"  class="form-control" name="end_date" required>
                                </div>

                                <div class="d-grid mx-auto">
                                    <button type="submit" class="btn btn-dark btn-block">Search</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Nasir Vai Assignment\Assignment\resources\views/income/startEndDate.blade.php ENDPATH**/ ?>