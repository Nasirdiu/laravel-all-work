<div class="container mx-auto  lg:px-44 my-12 ">
      <h2 class="text-2xl text-center my-1">FEATURED CATEGORIES</h2>
      <h2 class="text-md text-center my-1">Get your desired product from featured category</h2>

    <div class="grid my-8 grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Phones%20&%20Tablets-01-3944.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/power-adapter-6971.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Macbook-01-4687.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Smart%20Watch-01-6571.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/airpods-8799.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Overhead%20Headphone-01-1816.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Phones%20&%20Tablets-01-3944.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Overhead%20Headphone-01-1816.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>


    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Wireless%20Charger-01-2920.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-6 shadow">
      <img class="w-16" src="https://adminapi.applegadgetsbd.com/storage/media/medium/Phones%20&%20Tablets-01-3944.png"/>
      <h2 class="text-md my-2">Macbook Laptop</h2>
    </a>



  </div>
</div>
