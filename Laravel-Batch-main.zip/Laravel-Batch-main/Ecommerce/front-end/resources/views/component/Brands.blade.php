<div class="container mx-auto  lg:px-44 my-12 ">
      <h2 class="text-2xl text-center my-1">CHOOSE BRANDS</h2>
      <h2 class="text-md text-center my-1">Get your desired product from top brands</h2>

    <div class="grid my-8 grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">

    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-4 shadow">
      <img class="w-16" src="https://www.seekpng.com/png/detail/9-95668_apple-logos-download-clipart-freeuse-apple-logo-png.png"/>
      <h2 class="text-md my-1">Apple</h2>
    </a>
    <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-4 shadow">
        <img class="w-16" src="https://www.seekpng.com/png/detail/9-95668_apple-logos-download-clipart-freeuse-apple-logo-png.png"/>
        <h2 class="text-md my-1">Apple</h2>
    </a>

        <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-4 shadow">
            <img class="w-16" src="https://www.seekpng.com/png/detail/9-95668_apple-logos-download-clipart-freeuse-apple-logo-png.png"/>
            <h2 class="text-md my-1">Apple</h2>
        </a>
        <a href="" class="card grayscale hover:grayscale-0 bg-slate-100 items-center  p-4 shadow">
            <img class="w-16" src="https://www.seekpng.com/png/detail/9-95668_apple-logos-download-clipart-freeuse-apple-logo-png.png"/>
            <h2 class="text-md my-1">Apple</h2>
        </a>

  </div>
</div>
