<section class="container my-5" id="Contact">
    <div>
        <h1 class="text-center my-4">Send Your <span class="nav-span">Message</span></h1>
    </div>
    <div class="row d-flex justify-content-center ">
        <div class="col-md-4 d-flex flex-column">
            <form action="" class=" text-center ">
                <input class="form-control mb-2" type="text" placeholder="Your Name" aria-label="">
                <input class="form-control mb-2" type="email" placeholder="Your Email" aria-label="">
                <textarea name="text" id="" cols="30" rows="5" placeholder="Message"></textarea> <br>
                <button class="btn btn-danger text-center" type="submit">SUBMIT</button>
            </form>
        </div>

    </div>

</section>
