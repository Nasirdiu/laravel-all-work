<footer>
    <div class="container my-5">
        <div class="row d-flex justify-content-between align-items-center  ">
            <div class="col-md-4 mt-5">
                <p class="text-center text-white">© 2023 Marrige. All rights reserved</p>
            </div>
            <div class="col-md-4 mt-5 d-flex flex-column justify-content-center align-items-center ">
                <h3 class="text-white">Get the App</h3>

                <a target="_blank" href="https://apps.apple.com/us/app/camera/id1584216193"> <img
                        class=" img-fluid my-2 " src="images/App Store Badge.png" alt=""></a>
                <a target="_blank"
                   href="https://play.google.com/store/apps/details?id=com.learnprogramming.codecamp&hl=en&gl=US"><img
                        class="img-fluid" src="images/Google Play Badge.png" alt=""></a>

            </div>
        </div>
    </div>
</footer>
