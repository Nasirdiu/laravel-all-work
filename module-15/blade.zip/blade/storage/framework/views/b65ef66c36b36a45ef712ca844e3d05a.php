<div class="container mt-3">

    <div class="toast show ms-auto">
        <div class="toast-header bg-info">
            <strong class="me-auto bg-gradient fs-3">50% Discount</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
            <p class="fs-6">Per Night $1000</p>
        </div>
    </div>
</div>
<?php /**PATH C:\ostad php\laravel\module-15\blade\resources\views/compoents/tost.blade.php ENDPATH**/ ?>