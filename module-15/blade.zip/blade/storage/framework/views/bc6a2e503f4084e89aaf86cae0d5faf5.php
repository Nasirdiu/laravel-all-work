<section class="container my-5" id="Room">


    <hr>
    <marquee behavior="" direction="">

        <h2 class="text-center"> <span class="nav-span">WELCOME </span> TO HOTEL SARINA WEDDING VENUES ROOM</h2>
    </marquee>
    <hr>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card" style="width: 18rem;">
                <img src="./images/deluxe-01.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">HOTEL ROOM</h5>
                    <p class="card-text">At Deluxe twin you can indulge yourself in a big luxurious bed to
                        relieve your all day’s hustle and bustle. The rooms are well equipped with all the
                        necessary amenities</p>
                    <a href="https://sarinahotel.com/" class="btn btn-primary">Go Where</a>
                </div>
            </div>

        </div>

        <div class="col-md-4">
            <div class="card" style="width: 18rem;">
                <img src="./images/deluxe-twin-01.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">HOTEL ROOM</h5>
                    <p class="card-text">At Deluxe twin you can indulge yourself in a big luxurious bed to
                        relieve your all day’s hustle and bustle. The rooms are well equipped with all the
                        necessary amenities</p>
                    <a href="https://sarinahotel.com/" class="btn btn-primary">Go Where</a>
                </div>
            </div>

        </div>
        <div class="col-md-4">
            <div class="card" style="width: 18rem;">
                <img src="./images/deluxe-twin-01.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">HOTEL ROOM</h5>
                    <p class="card-text">At Deluxe twin you can indulge yourself in a big luxurious bed to
                        relieve your all day’s hustle and bustle. The rooms are well equipped with all the
                        necessary amenities</p>
                    <a href="https://sarinahotel.com/" class="btn btn-primary">Go Where</a>
                </div>
            </div>

        </div>
    </div>


</section>
<?php /**PATH C:\ostad php\laravel\module-15\blade\resources\views/compoents/card.blade.php ENDPATH**/ ?>